namespace CleaArchitecture.Domain.Vehiculos;

public enum Accesorio
{
    Wifi = 1,
    AireAcondicionado = 2,
    AppleCar = 3,
    AndroidCar = 4,
    Mapas = 5
}